package Novin.A;




import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
//import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    int CounterStrike = 0;
    int CounterBall = 0;
    TextView StrikeRTxt;
    TextView BallRTxt;
    Button StrikeBt;
    Button BallBt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //declare the button & textView id
        StrikeRTxt = (TextView) findViewById(R.id.StrikeRTxt);
        BallRTxt = (TextView) findViewById(R.id.BallRTxt);
        StrikeBt = (Button) findViewById(R.id.StrikeBt);
        BallBt = (Button) findViewById(R.id.BallBt);


        StrikeBt.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                CounterStrike++;     //each click will increase number of strike
                // StrikeRTxt.setText(String.valueOf(CounterStrike)); // convert string to int
                StrikeRTxt.setText(Integer.toString(CounterStrike));

                //case of 3 strike == out
                if (CounterStrike == 3) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("Out");
                    builder.setNegativeButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    CounterStrike = 0;
                    CounterBall = 0;
                    //  StrikeRTxt.setText(String.valueOf(CounterStrike));
                    StrikeRTxt.setText(Integer.toString(CounterStrike));
                    BallRTxt.setText(Integer.toString(CounterBall));

                    //BallRTxt.setText(String.valueOf(CounterBall));

                }


            }
        });


        //click Ball button
        BallBt.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                CounterBall++;     //each click will increase number of strike
                BallRTxt.setText(Integer.toString(CounterBall));


                //case of 5 Ball == out

                if (CounterBall == 4) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("Out");
                    builder.setNegativeButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    CounterStrike = 0;
                    CounterBall = 0;
                    StrikeRTxt.setText(Integer.toString(CounterStrike));
                    BallRTxt.setText(Integer.toString(CounterBall));

                    // BallRTxt.setText(String.valueOf(CounterBall));
                    //StrikeRTxt.setText(String.valueOf(CounterStrike));


                }
            }
        });
    }
}